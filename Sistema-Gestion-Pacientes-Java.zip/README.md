# Sistema de Gestión de Pacientes

Aplicación web académica para registrar, consultar, editar y eliminar pacientes.

## Tecnologías
- Java 17
- Jakarta EE 10 (Servlet)
- JSP + JSTL
- Patrón MVC y DAO
- MySQL 8
- Maven
- Payara 7
- Bootstrap 5

## Estructura
- `modelo`: clase Paciente.
- `dao`: consultas SQL y operaciones CRUD.
- `controlador`: servlet que recibe las solicitudes.
- `config`: conexión a MySQL.
- `src/main/webapp/WEB-INF/vistas`: páginas JSP.
- `database`: script de creación y datos de prueba.

## Instalación
1. Inicia MySQL.
2. Abre phpMyAdmin o MySQL Workbench y ejecuta `database/hospital_2027.sql`.
3. Abre el proyecto como proyecto Maven en NetBeans o IntelliJ.
4. En `Conexion.java`, configura `USER` y `PASSWORD` según tu MySQL.
5. Compila con `mvn clean package`.
6. Despliega `target/sistema-gestion-pacientes.war` en Payara 7.
7. Abre `http://localhost:8080/sistema-gestion-pacientes/`.

## Funciones
- Listar pacientes.
- Registrar pacientes.
- Editar pacientes.
- Eliminar pacientes.
- Validación básica de campos y DNI de 8 dígitos.

## Modelo de base de datos
Tabla `pacientes`: `id`, `nombres`, `apellidos`, `dni`, `fecha_nacimiento`, `telefono`, `correo`, `direccion`, `fecha_registro`.

> Proyecto académico de demostración. No usar datos médicos reales ni información personal real.
